﻿using System;

class Program
{
    static void Main()
    {
        //ship
        int Sx1 = int.Parse(Console.ReadLine());
        int Sy1 = int.Parse(Console.ReadLine());
        int Sx2 = int.Parse(Console.ReadLine());
        int Sy2 = int.Parse(Console.ReadLine());
        int swaper1 = 0;
        int swaper2 = 0;
        int horisont = int.Parse(Console.ReadLine());
        //catapult
        int cx1 = int.Parse(Console.ReadLine());
        int cy1 = int.Parse(Console.ReadLine());
        int cx2 = int.Parse(Console.ReadLine());
        int cy2 = int.Parse(Console.ReadLine());
        int cx3 = int.Parse(Console.ReadLine());
        int cy3 = int.Parse(Console.ReadLine());

        swaper1 = Math.Min(Sx1, Sx2);
        swaper2 = Math.Max(Sx1, Sx2);

        Sx1 = swaper1;
        Sx2 = swaper2;

        swaper1 = Math.Min(Sy1, Sy2);
        swaper2 = Math.Max(Sy1, Sy2);

        Sy1 = swaper1;
        Sy2 = swaper2;

        cy1 = horisont * 2 - cy1;
        cy2 = horisont * 2 - cy2;
        cy3 = horisont * 2 - cy3;

        int damage = 0;


        damage+= CalculateDamage(Sx1, Sy1, Sx2, Sy2, cx1, cy1);
        damage += CalculateDamage(Sx1, Sy1, Sx2, Sy2, cx2, cy2);
        damage += CalculateDamage(Sx1, Sy1, Sx2, Sy2, cx3, cy3);

        Console.WriteLine(damage+"%");
        

    }

    private static int CalculateDamage(int Sx1, int Sy1, int Sx2, int Sy2, int cx1, int cy1)
    {
        int damage = 0;

        if (cx1 > Sx1 && cx1 < Sx2 && cy1 > Sy1 && cy1 < Sy2)
        {
            damage += 100;
        }

        else if ((cx1 == Sx1 || cx1 == Sx2) && cy1 > Sy1 && cy1 < Sy2)
        {
            damage += 50;
        }
        else if ((cy1 == Sy1 || cy1 == Sy2) && cx1 > Sx1 && cx1 < Sx2)
        {
            damage += 50;
        }
        else if ((cx1 == Sx1 || cx1 == Sx2) && (cy1 == Sy1 || cy1 == Sy2))
        {
            damage += 25;
        }

        return damage;
    }
}

