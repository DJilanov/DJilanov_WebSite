﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task5___FallDown
{
    class Program
    {
        static void Main()
        {
            int[,] matrix  = new int[8,8];

            for (int i = 0; i < 8; i++)
            {
                int number = int.Parse(Console.ReadLine());
                for (int j = 0; j < 8; j++)
                {
                    matrix[i, j] = number >> j & 1;
                }
            }

            for (int i = 7; i >= 0; i--)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (matrix[i, j] == 1)
                    {
                        matrix[i,j]=0;

                        bool found = false;
                        int lastRow = 7;
                        while (!found)
                        {
                            if (matrix[lastRow, j] == 0)
                            {
                                matrix[lastRow, j] = 1;
                                found = true;
                            }
                            --lastRow;
                            if (lastRow < 0) break;
                        }
                    }

                }

             
            }

            for (int i = 0; i < 8; i++)
            {
                string str = "";
                for (int j = 7; j >= 0; j--)
                {
                    str += matrix[i,j];
                }
                Console.WriteLine(Convert.ToInt32(str, 2));
            }
        }
        
    }
}
