﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1___Math_Expression
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal n = decimal.Parse(Console.ReadLine());
            decimal m = decimal.Parse(Console.ReadLine());
            decimal p = decimal.Parse(Console.ReadLine());
            decimal trunc = Math.Truncate(m % 180m);

            decimal nom = (n * n) + (1 / (m * p)) + 1337m;
            decimal denom = n - 128.523123123m * p;
            decimal result = (nom / denom) + (decimal)(Math.Sin((double)(trunc)));

            Console.WriteLine("{0:f6}", result);
        }
    }
}
